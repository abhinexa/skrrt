"""
Adaptive Safety Digital Twin — FastAPI Backend
================================================
Handles: sensor simulation, risk computation, prediction, WebSocket streaming

Run: uvicorn backend:app --reload --port 8000
Install: pip install fastapi uvicorn websockets numpy
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import asyncio
import json
import math
import random
import time
from collections import deque

# ─────────────────────────────────────────────────
# APP SETUP
# ─────────────────────────────────────────────────
app = FastAPI(
    title="Adaptive Safety Digital Twin API",
    description="Risk computation and simulation for smart factory cyber-physical safety",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─────────────────────────────────────────────────
# MODELS
# ─────────────────────────────────────────────────
class SensorReading(BaseModel):
    zone: str
    temperature: float = 25.0
    humidity: float = 50.0
    gas: float = 50.0
    air_quality: float = 45.0
    radiation: float = 0.1
    vibration: float = 0.5
    machine_load: float = 60.0
    noise: float = 65.0
    pressure: float = 101.0
    motion: int = 0
    worker_density: float = 3.0
    fatigue: float = 3.0
    forklift: float = 2.0
    door_state: int = 0
    ventilation: float = 80.0


class RiskResult(BaseModel):
    zone: str
    R: float
    state: str
    vent_on: bool
    contributions: list
    timestamp: float


# ─────────────────────────────────────────────────
# RISK ENGINE
# Based on paper: "Context-Aware, Trend-Sensitive, Explainable Risk
# Estimation Framework for Safety-Critical Edge IoT Systems"
# ─────────────────────────────────────────────────
class RiskEngine:
    # Classification thresholds (from paper §III.E)
    THETA_1 = 0.30   # Safe → Warning
    THETA_2 = 0.60   # Warning → Danger

    # Temporal window for temperature trend
    DELTA_T_MAX = 15.0  # Max expected temperature rise (°C) in window
    ALPHA = 0.5          # Dynamic weight amplification factor

    # Base sensor weights (sum ≈ 1 when ventilation=1)
    WEIGHTS = {
        'gas':          0.15,   # Amplified by motion
        'motion':       0.08,
        'temp_trend':   0.10,   # Based on rate of change, not absolute
        'humidity':     0.04,
        'air_quality':  0.08,
        'radiation':    0.06,
        'vibration':    0.05,
        'machine_load': 0.05,
        'noise':        0.04,
        'pressure':     0.04,
        'worker_density': 0.07,
        'fatigue':      0.06,
        'forklift':     0.06,
        'door_state':   0.03,
        'ventilation':  0.08,   # Negative contribution (reduces risk)
    }

    def normalize(self, sensors: dict) -> dict:
        """Normalize all sensor inputs to [0,1]"""
        return {
            'G':    min(sensors['gas'] / 1000, 1.0),
            'M':    float(sensors['motion']),
            'H':    min(sensors['humidity'] / 100, 1.0),
            'AQ':   min(sensors['air_quality'] / 500, 1.0),
            'Rad':  min(sensors['radiation'] / 10, 1.0),
            'Vib':  min(sensors['vibration'] / 10, 1.0),
            'ML':   min(sensors['machine_load'] / 100, 1.0),
            'N':    min(sensors['noise'] / 120, 1.0),
            'P':    min(abs(sensors['pressure'] - 101) / 99, 1.0),  # Deviation from standard
            'WD':   min(sensors['worker_density'] / 20, 1.0),
            'F':    min(sensors['fatigue'] / 10, 1.0),
            'FK':   min(sensors['forklift'] / 10, 1.0),
            'D':    float(sensors['door_state']),
            'Vent': 1.0 - min(sensors['ventilation'] / 100, 1.0),  # Inverse: high vent → low risk
        }

    def compute_temp_trend(self, temp_history: deque) -> float:
        """
        Temporal trend analysis (paper §III.C):
        T'(t) = min(|ΔT(t)| / ΔT_max, 1)
        where ΔT(t) = x_t(t) - x_t(t - τ)
        """
        if len(temp_history) < 2:
            return 0.0
        delta_t = abs(temp_history[-1] - temp_history[0])
        return min(delta_t / self.DELTA_T_MAX, 1.0)

    def compute(self, sensors: dict, temp_history: deque) -> dict:
        """
        Main risk computation (paper §III.D):
        R(t) = Σ w_i(t) · S_i(t)

        Dynamic weights: w_g(t) = w_g0 · (1 + α · M(t))
        """
        s = self.normalize(sensors)
        T_trend = self.compute_temp_trend(temp_history)
        W = self.WEIGHTS

        # Dynamic weight amplification for gas (from paper §III.D)
        # wg(t) = wg0 · (1 + α · M(t))
        wg_dynamic = W['gas'] * (1 + self.ALPHA * s['M'])

        # Weighted fusion (from paper eq. 5)
        contributions = {
            'Gas':          wg_dynamic * s['G'],
            'Motion':       W['motion'] * s['M'],
            'Temp Trend':   W['temp_trend'] * T_trend,
            'Humidity':     W['humidity'] * s['H'],
            'Air Quality':  W['air_quality'] * s['AQ'],
            'Radiation':    W['radiation'] * s['Rad'],
            'Vibration':    W['vibration'] * s['Vib'],
            'Machine Load': W['machine_load'] * s['ML'],
            'Noise':        W['noise'] * s['N'],
            'Pressure':     W['pressure'] * s['P'],
            'Workers':      W['worker_density'] * s['WD'],
            'Fatigue':      W['fatigue'] * s['F'],
            'Forklift':     W['forklift'] * s['FK'],
            'Door':         W['door_state'] * s['D'],
            'Ventilation':  -W['ventilation'] * (1 - s['Vent']),  # Negative: reduces R
        }

        R = sum(contributions.values())
        R = max(0.0, min(1.0, R))  # Bounded [0,1]

        # Classification (from paper §III.E)
        if R < self.THETA_1:
            state = 'SAFE'
        elif R < self.THETA_2:
            state = 'WARNING'
        else:
            state = 'DANGER'

        # Ventilation logic (from paper §III.F):
        # Fan ON if gas > 50% max OR R ≥ danger threshold
        vent_on = (s['G'] > 0.5 or R >= self.THETA_2)

        return {
            'R': round(R, 4),
            'state': state,
            'vent_on': vent_on,
            'contributions': [
                {'name': k, 'value': round(v, 5)}
                for k, v in sorted(contributions.items(), key=lambda x: abs(x[1]), reverse=True)
            ],
            'normalized': s,
            'temp_trend': round(T_trend, 4),
        }


# ─────────────────────────────────────────────────
# PREDICTION MODULE
# Simple linear regression over rolling window
# ─────────────────────────────────────────────────
class PredictionModule:
    def __init__(self, horizon: int = 30):
        self.horizon = horizon  # seconds into the future

    def linear_regression(self, data: list) -> tuple[float, float]:
        """Compute slope and intercept via least squares."""
        n = len(data)
        if n < 2:
            return 0.0, data[-1] if data else 0.0
        x_mean = (n - 1) / 2
        y_mean = sum(data) / n
        num = sum((i - x_mean) * (y - y_mean) for i, y in enumerate(data))
        den = sum((i - x_mean) ** 2 for i in range(n))
        slope = num / den if den != 0 else 0
        intercept = y_mean - slope * x_mean
        return slope, intercept

    def predict(self, history: list) -> dict:
        """Predict risk score at t+horizon seconds."""
        if len(history) < 3:
            return {'predicted': history[-1] if history else 0.0, 'spike_probability': 0.0, 'trend': 'stable'}

        window = history[-min(len(history), 30):]
        slope, intercept = self.linear_regression(window)
        x_pred = len(window) + self.horizon
        predicted = max(0.0, min(1.0, slope * x_pred + intercept))

        # Spike probability: increasing trend towards danger threshold
        current = window[-1]
        spike_prob = max(0.0, min(1.0, (predicted - 0.4) / 0.4)) if predicted > 0.4 else 0.0

        trend = 'rising' if slope > 0.002 else 'falling' if slope < -0.002 else 'stable'

        return {
            'predicted': round(predicted, 4),
            'current': round(current, 4),
            'slope': round(slope, 6),
            'spike_probability': round(spike_prob, 4),
            'trend': trend,
            'horizon_seconds': self.horizon,
        }


# ─────────────────────────────────────────────────
# SYNTHETIC DATA GENERATOR
# ─────────────────────────────────────────────────
class SyntheticGenerator:
    """Generates realistic sensor data with:
    - Gaussian noise
    - Correlated spikes (gas + motion)
    - Rare extreme events
    - Zone-specific characteristics
    """

    ZONE_PROFILES = {
        'A': {'base': {'temperature': 22, 'gas': 40, 'machine_load': 30, 'noise': 55, 'worker_density': 2}},
        'B': {'base': {'temperature': 42, 'gas': 120, 'machine_load': 80, 'noise': 85, 'worker_density': 8}},
        'C': {'base': {'temperature': 30, 'gas': 60, 'machine_load': 60, 'noise': 70, 'worker_density': 6}},
        'D': {'base': {'temperature': 22, 'gas': 20, 'machine_load': 20, 'noise': 45, 'worker_density': 1}},
    }

    def __init__(self):
        self.states = {z: self._init_zone(z) for z in ['A', 'B', 'C', 'D']}
        self.spike_event = None

    def _init_zone(self, zone: str) -> dict:
        base = self.ZONE_PROFILES[zone]['base']
        return {
            'temperature': base.get('temperature', 25),
            'humidity': 50.0,
            'gas': base.get('gas', 50),
            'air_quality': 45.0,
            'radiation': 0.1,
            'vibration': 0.5,
            'machine_load': base.get('machine_load', 60),
            'noise': base.get('noise', 65),
            'pressure': 101.0,
            'motion': 0,
            'worker_density': base.get('worker_density', 3),
            'fatigue': 3.0,
            'forklift': 2.0,
            'door_state': 0,
            'ventilation': 80.0,
        }

    def _noise(self, val, std, lo=0.0, hi=100.0, drift=0.0) -> float:
        return max(lo, min(hi, val + random.gauss(0, std) + drift))

    def _maybe_trigger_spike(self):
        """Rare extreme correlated event (0.2% chance per tick)"""
        if self.spike_event is None and random.random() < 0.002:
            zone = random.choice(['A', 'B', 'C', 'D'])
            event_type = random.choice(['gas_motion', 'thermal'])
            duration = random.randint(15, 45)
            self.spike_event = {'zone': zone, 'type': event_type, 'duration': duration, 'tick': 0}

    def tick(self) -> dict:
        """Advance simulation by one timestep, return all zone readings."""
        self._maybe_trigger_spike()
        if self.spike_event:
            self.spike_event['tick'] += 1
            if self.spike_event['tick'] >= self.spike_event['duration']:
                self.spike_event = None

        results = {}
        for zone, s in self.states.items():
            is_spike = self.spike_event and self.spike_event['zone'] == zone
            gas_spike = is_spike and self.spike_event['type'] == 'gas_motion'
            thermal_spike = is_spike and self.spike_event['type'] == 'thermal'
            spike_factor = (
                math.sin(math.pi * self.spike_event['tick'] / self.spike_event['duration'])
                if is_spike else 0.0
            )

            s['temperature'] = self._noise(s['temperature'], 0.6, 10, 90,
                                            drift=spike_factor * 3 if thermal_spike else 0)
            s['humidity'] = self._noise(s['humidity'], 1.0, 20, 95)
            s['gas'] = self._noise(s['gas'], 12, 0, 900,
                                    drift=spike_factor * 200 if gas_spike else 0)
            s['air_quality'] = self._noise(s['air_quality'], 6, 10, 450,
                                            drift=spike_factor * 80 if gas_spike else 0)
            s['radiation'] = self._noise(s['radiation'], 0.03, 0, 8)
            s['vibration'] = self._noise(s['vibration'], 0.15, 0, 8)
            s['machine_load'] = self._noise(s['machine_load'], 2.5, 0, 100)
            s['noise'] = self._noise(s['noise'], 1.5, 30, 115)
            s['pressure'] = self._noise(s['pressure'], 0.8, 90, 115)

            # Motion: correlated with gas spikes, human presence, time
            if gas_spike and spike_factor > 0.5:
                s['motion'] = 1
            elif random.random() < 0.02:
                s['motion'] = 1 - s['motion']

            s['worker_density'] = self._noise(s['worker_density'], 0.2, 0, 18)
            s['fatigue'] = self._noise(s['fatigue'], 0.15, 0, 9.5)
            s['forklift'] = self._noise(s['forklift'], 0.2, 0, 9)

            if random.random() < 0.008:
                s['door_state'] = 1 - s['door_state']

            # Ventilation auto-response to high gas
            if s['gas'] / 1000 > 0.5:
                s['ventilation'] = min(s['ventilation'] + 2, 100)
            else:
                s['ventilation'] = self._noise(s['ventilation'], 0.5, 40, 100)

            results[zone] = {k: round(v, 3) if isinstance(v, float) else v
                             for k, v in s.items()}

        return results


# ─────────────────────────────────────────────────
# GLOBAL STATE
# ─────────────────────────────────────────────────
engine = RiskEngine()
predictor = PredictionModule(horizon=30)
generator = SyntheticGenerator()

# Per-zone state
zone_risk_history: dict[str, deque] = {z: deque(maxlen=300) for z in ['A', 'B', 'C', 'D']}
zone_temp_history: dict[str, deque] = {z: deque(maxlen=10) for z in ['A', 'B', 'C', 'D']}
zone_sensor_cache: dict[str, dict] = {}

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active: list[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)

    def disconnect(self, ws: WebSocket):
        self.active.remove(ws)

    async def broadcast(self, data: dict):
        msg = json.dumps(data)
        disconnected = []
        for ws in self.active:
            try:
                await ws.send_text(msg)
            except:
                disconnected.append(ws)
        for ws in disconnected:
            self.active.remove(ws)


manager = ConnectionManager()


# ─────────────────────────────────────────────────
# BACKGROUND SIMULATION TASK
# ─────────────────────────────────────────────────
async def simulation_task():
    """Main simulation loop: runs at 1 Hz, broadcasts results via WebSocket."""
    while True:
        await asyncio.sleep(1.0)
        try:
            # Generate synthetic sensor data
            sensor_data = generator.tick()
            zone_sensor_cache.update(sensor_data)

            # Compute risk per zone
            zone_results = {}
            for zone, sensors in sensor_data.items():
                zone_temp_history[zone].append(sensors['temperature'])
                result = engine.compute(sensors, zone_temp_history[zone])
                zone_risk_history[zone].append(result['R'])
                prediction = predictor.predict(list(zone_risk_history[zone]))
                zone_results[zone] = {
                    **result,
                    'sensors': sensors,
                    'prediction': prediction,
                    'timestamp': time.time(),
                }

            # Global assessment
            states = [z['state'] for z in zone_results.values()]
            global_state = ('DANGER' if 'DANGER' in states else
                           'WARNING' if 'WARNING' in states else 'SAFE')

            payload = {
                'type': 'update',
                'timestamp': time.time(),
                'global_state': global_state,
                'zones': zone_results,
                'any_vent_on': any(z['vent_on'] for z in zone_results.values()),
            }

            await manager.broadcast(payload)
        except Exception as e:
            print(f"[SimLoop Error] {e}")


@app.on_event("startup")
async def startup():
    asyncio.create_task(simulation_task())


# ─────────────────────────────────────────────────
# REST ENDPOINTS
# ─────────────────────────────────────────────────
@app.get("/")
def root():
    return {"status": "ok", "service": "Adaptive Safety Digital Twin API v1.0"}


@app.get("/health")
def health():
    return {"status": "healthy", "zones_monitored": 4, "sensors_per_zone": 15}


@app.post("/risk/compute", response_model=RiskResult)
def compute_risk_endpoint(reading: SensorReading):
    """Compute risk score for a single sensor reading."""
    sensors = reading.dict(exclude={'zone'})
    hist = zone_temp_history.get(reading.zone, deque())
    result = engine.compute(sensors, hist)
    return RiskResult(
        zone=reading.zone,
        R=result['R'],
        state=result['state'],
        vent_on=result['vent_on'],
        contributions=result['contributions'],
        timestamp=time.time(),
    )


@app.get("/zones/{zone}/status")
def get_zone_status(zone: str):
    """Get current status for a specific zone."""
    zone = zone.upper()
    if zone not in ['A', 'B', 'C', 'D']:
        raise HTTPException(status_code=404, detail=f"Zone {zone} not found")
    sensors = zone_sensor_cache.get(zone, generator._init_zone(zone))
    hist = zone_temp_history.get(zone, deque())
    result = engine.compute(sensors, hist)
    prediction = predictor.predict(list(zone_risk_history.get(zone, deque())))
    return {
        'zone': zone,
        'sensors': sensors,
        'risk': result,
        'prediction': prediction,
        'history_len': len(zone_risk_history.get(zone, [])),
    }


@app.get("/zones/all/status")
def get_all_zones():
    """Get current status for all zones."""
    results = {}
    for zone in ['A', 'B', 'C', 'D']:
        sensors = zone_sensor_cache.get(zone, generator._init_zone(zone))
        hist = zone_temp_history.get(zone, deque())
        result = engine.compute(sensors, hist)
        prediction = predictor.predict(list(zone_risk_history.get(zone, deque())))
        results[zone] = {'sensors': sensors, 'risk': result, 'prediction': prediction}
    return results


@app.get("/zones/{zone}/history")
def get_zone_history(zone: str, limit: int = 60):
    """Get risk history for a zone."""
    zone = zone.upper()
    history = list(zone_risk_history.get(zone, []))
    return {'zone': zone, 'history': history[-limit:], 'count': len(history)}


@app.post("/zones/{zone}/sensors")
def update_zone_sensors(zone: str, reading: SensorReading):
    """Override sensor values for a specific zone (manual control)."""
    zone = zone.upper()
    zone_sensor_cache[zone] = reading.dict(exclude={'zone'})
    return {"status": "updated", "zone": zone}


@app.get("/prediction/{zone}")
def get_prediction(zone: str, horizon: int = 30):
    """Get risk prediction for a zone."""
    zone = zone.upper()
    custom_predictor = PredictionModule(horizon=horizon)
    history = list(zone_risk_history.get(zone, []))
    return custom_predictor.predict(history)


@app.get("/alerts/generate")
def generate_alert_messages():
    """Generate alert messages based on current zone states."""
    alerts = []
    for zone in ['A', 'B', 'C', 'D']:
        sensors = zone_sensor_cache.get(zone, {})
        hist = zone_temp_history.get(zone, deque())
        result = engine.compute(sensors, hist)
        if result['state'] == 'DANGER':
            gas_high = sensors.get('gas', 0) > 500
            motion = sensors.get('motion', 0)
            if gas_high and motion:
                alerts.append({
                    'level': 'DANGER',
                    'zone': zone,
                    'message': f'DANGER: High gas ({sensors.get("gas",0):.0f} ppm) + human presence in Zone {zone}',
                    'R': result['R'],
                })
            else:
                alerts.append({
                    'level': 'DANGER',
                    'zone': zone,
                    'message': f'DANGER: Critical risk condition in Zone {zone} (R={result["R"]:.3f})',
                    'R': result['R'],
                })
        elif result['state'] == 'WARNING':
            alerts.append({
                'level': 'WARNING',
                'zone': zone,
                'message': f'WARNING: Elevated risk in Zone {zone} (R={result["R"]:.3f})',
                'R': result['R'],
            })
    return {'alerts': alerts, 'timestamp': time.time()}


# ─────────────────────────────────────────────────
# WEBSOCKET ENDPOINT
# ─────────────────────────────────────────────────
@app.websocket("/ws/live")
async def websocket_live(websocket: WebSocket):
    """
    WebSocket endpoint for real-time risk data streaming.
    Client receives JSON every second with all zone data.
    """
    await manager.connect(websocket)
    try:
        # Send initial state on connect
        init_data = {}
        for zone in ['A', 'B', 'C', 'D']:
            sensors = zone_sensor_cache.get(zone, generator._init_zone(zone))
            hist = zone_temp_history.get(zone, deque())
            result = engine.compute(sensors, hist)
            init_data[zone] = {**result, 'sensors': sensors, 'timestamp': time.time()}
        await websocket.send_text(json.dumps({'type': 'init', 'zones': init_data}))

        # Keep connection alive, receive optional sensor overrides
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            if msg.get('type') == 'sensor_update':
                zone = msg['zone'].upper()
                zone_sensor_cache[zone] = msg['sensors']
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        print(f"[WebSocket Error] {e}")
        manager.disconnect(websocket)


# ─────────────────────────────────────────────────
# DATASET GENERATOR (export synthetic data)
# ─────────────────────────────────────────────────
@app.get("/dataset/generate")
def generate_dataset(samples: int = 100, zone: str = 'B'):
    """Generate a synthetic dataset for training/testing."""
    gen = SyntheticGenerator()
    engine_local = RiskEngine()
    temp_hist = deque(maxlen=10)
    records = []

    for _ in range(samples):
        data = gen.tick()
        sensors = data[zone.upper()]
        temp_hist.append(sensors['temperature'])
        result = engine_local.compute(sensors, temp_hist)
        records.append({
            **sensors,
            'R': result['R'],
            'state': result['state'],
            'vent_on': result['vent_on'],
            'temp_trend': result['temp_trend'],
        })

    return {'zone': zone.upper(), 'samples': len(records), 'data': records}


if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
