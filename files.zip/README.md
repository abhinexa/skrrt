# Adaptive Safety Digital Twin for Smart Factories

## Files
| File | Purpose |
|------|---------|
| `adaptive_safety_digital_twin.html` | Complete frontend — open in any browser |
| `backend.py` | FastAPI backend with WebSocket streaming |
| `risk_engine.py` | Standalone risk engine + data generator |

## Quick Start

### Frontend (standalone, no backend needed)
Just open `adaptive_safety_digital_twin.html` in Chrome/Firefox.

### Backend
```bash
pip install fastapi uvicorn websockets numpy
python backend.py
# API at http://localhost:8000
# Docs at http://localhost:8000/docs
# WS  at ws://localhost:8000/ws/live
```

### Risk Engine (standalone)
```python
from risk_engine import RiskEngine, SyntheticGenerator, PredictionModule
engine = RiskEngine()
gen    = SyntheticGenerator()
pred   = PredictionModule(horizon=30)

data   = gen.tick()
result = engine.compute(data['B'], temp_history=[25,26,28])
print(engine.explain(result))
```

## API Endpoints
| Method | Path | Description |
|--------|------|-------------|
| GET | `/zones/all/status` | All zone risk states |
| GET | `/zones/{zone}/status` | Single zone risk |
| POST | `/risk/compute` | Compute risk from sensor POST |
| GET | `/prediction/{zone}` | 30-second risk prediction |
| GET | `/dataset/generate?samples=100` | Export synthetic dataset |
| WS | `/ws/live` | Real-time 1 Hz stream |

## Risk Model (from research paper)
- **15 sensors**: temperature, humidity, gas, AQI, radiation, vibration,
  machine load, noise, pressure, motion, worker density, fatigue,
  forklift activity, door state, ventilation efficiency
- **Normalization**: S_i(t) = min(x_i / x_max, 1)
- **Temperature trend**: T'(t) = min(|ΔT| / ΔT_max, 1)
- **Dynamic weights**: w_g(t) = w_g0 · (1 + α · M(t))
- **Risk score**: R(t) = Σ w_i(t) · S_i(t) ∈ [0,1]
- **Thresholds**: SAFE < 0.30, WARNING 0.30–0.60, DANGER ≥ 0.60
