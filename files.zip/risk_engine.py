"""
risk_engine.py — Standalone Risk Computation Module
=====================================================
Context-Aware Multi-Sensor Risk Estimation
Based on: "Context-Aware, Trend-Sensitive, Explainable Risk Estimation
Framework for Safety-Critical Edge IoT Systems Using Multi-Sensor Fusion"

Usage:
    from risk_engine import RiskEngine, SyntheticGenerator, PredictionModule
    engine = RiskEngine()
    result = engine.compute(sensors, temp_history)
"""

from collections import deque
import math


class RiskEngine:
    """
    Implements the weighted multi-sensor risk fusion model.

    Mathematical Model (from paper):
      1. Normalize: S_i(t) = min(x_i / x_max, 1)
      2. Temp trend: T'(t) = min(|ΔT(t)| / ΔT_max, 1)
      3. Motion: M(t) ∈ {0, 1}
      4. Dynamic weight: w_g(t) = w_g0 · (1 + α · M(t))
      5. Risk: R(t) = Σ w_i(t) · S_i(t)  ∈ [0, 1]
      6. State: SAFE(R<0.30), WARNING(0.30≤R<0.60), DANGER(R≥0.60)
      7. Vent: ON if gas > 50% ∨ R ≥ 0.60
    """

    # Thresholds (paper §III.E)
    THETA_1 = 0.30  # Safe → Warning
    THETA_2 = 0.60  # Warning → Danger
    THETA_T = 0.50  # Temperature trend early-warning threshold

    # Normalization maxima
    MAX_GAS       = 1000.0  # ppm
    MAX_TEMP      = 100.0   # °C
    MAX_HUMIDITY  = 100.0   # %
    MAX_AQ        = 500.0   # AQI
    MAX_RADIATION = 10.0    # mSv
    MAX_VIBRATION = 10.0    # g
    MAX_MACHINE   = 100.0   # %
    MAX_NOISE     = 120.0   # dB
    PRESS_REF     = 101.0   # kPa (standard atmospheric)
    PRESS_DEV     = 99.0    # Max expected deviation
    MAX_WORKERS   = 20.0    # per zone
    MAX_FATIGUE   = 10.0
    MAX_FORKLIFT  = 10.0
    MAX_VENT      = 100.0   # %

    # Temperature trend analysis
    DELTA_T_MAX = 15.0  # Max expected temperature rise in window (°C)

    # Dynamic amplification (paper §III.D)
    ALPHA = 0.5

    # Base weights (paper §III.D extended for 15 sensors)
    # Sum ≈ 1.0 at average ventilation
    BASE_WEIGHTS = {
        'gas':            0.15,   # Primary hazard — amplified by motion
        'motion':         0.08,   # Contextual amplifier
        'temp_trend':     0.10,   # Predictive temperature rise
        'humidity':       0.04,   # Environmental
        'air_quality':    0.08,   # Combined particles/gases
        'radiation':      0.06,   # Ionizing radiation
        'vibration':      0.05,   # Structural/machinery
        'machine_load':   0.05,   # Operational stress
        'noise':          0.04,   # Acoustic hazard
        'pressure':       0.04,   # Pneumatic/structural deviation
        'worker_density': 0.07,   # Human exposure
        'fatigue':        0.06,   # Human factor
        'forklift':       0.06,   # Mobile equipment hazard
        'door_state':     0.03,   # Containment (open = higher risk)
        'ventilation':    0.08,   # NEGATIVE: reduces risk
    }

    def normalize_all(self, sensors: dict) -> dict:
        """
        Normalize heterogeneous sensor inputs to [0,1].
        Gas, humidity, etc. use proportional normalization.
        Pressure uses deviation from standard atmospheric.
        Ventilation is inverse (high ventilation → low risk contribution).
        """
        return {
            'G':    min(sensors.get('gas', 0) / self.MAX_GAS, 1.0),
            'M':    float(sensors.get('motion', 0)),
            'H':    min(sensors.get('humidity', 50) / self.MAX_HUMIDITY, 1.0),
            'AQ':   min(sensors.get('air_quality', 45) / self.MAX_AQ, 1.0),
            'Rad':  min(sensors.get('radiation', 0) / self.MAX_RADIATION, 1.0),
            'Vib':  min(sensors.get('vibration', 0) / self.MAX_VIBRATION, 1.0),
            'ML':   min(sensors.get('machine_load', 60) / self.MAX_MACHINE, 1.0),
            'N':    min(sensors.get('noise', 65) / self.MAX_NOISE, 1.0),
            'P':    min(abs(sensors.get('pressure', 101) - self.PRESS_REF) / self.PRESS_DEV, 1.0),
            'WD':   min(sensors.get('worker_density', 3) / self.MAX_WORKERS, 1.0),
            'F':    min(sensors.get('fatigue', 3) / self.MAX_FATIGUE, 1.0),
            'FK':   min(sensors.get('forklift', 2) / self.MAX_FORKLIFT, 1.0),
            'D':    float(sensors.get('door_state', 0)),
            'Vent': 1.0 - min(sensors.get('ventilation', 80) / self.MAX_VENT, 1.0),
        }

    def compute_temp_trend(self, temp_history: deque) -> float:
        """
        Temperature trend analysis (paper §III.C):

            ΔT(t) = x_t(t) - x_t(t - τ)
            T'(t) = min(|ΔT(t)| / ΔT_max, 1)

        This enables early detection of thermal escalation even before
        absolute temperature thresholds are exceeded.
        """
        if len(temp_history) < 2:
            return 0.0
        delta = abs(temp_history[-1] - temp_history[0])
        return min(delta / self.DELTA_T_MAX, 1.0)

    def compute(self, sensors: dict, temp_history: deque) -> dict:
        """
        Main risk computation function.

        Returns:
            dict with keys: R, state, vent_on, contributions,
                            normalized, temp_trend, is_predictive_warning
        """
        s = self.normalize_all(sensors)
        T_prime = self.compute_temp_trend(temp_history)
        W = self.BASE_WEIGHTS

        # Dynamic weight for gas (paper §III.D: w_g(t) = w_g0 · (1 + α · M(t)))
        wg_t = W['gas'] * (1 + self.ALPHA * s['M'])

        # Weighted multi-sensor fusion (paper §III.D: R(t) = Σ w_i(t) · S_i(t))
        terms = {
            'Gas':          wg_t       * s['G'],
            'Motion':       W['motion']  * s['M'],
            'Temp Trend':   W['temp_trend'] * T_prime,
            'Humidity':     W['humidity'] * s['H'],
            'Air Quality':  W['air_quality'] * s['AQ'],
            'Radiation':    W['radiation']* s['Rad'],
            'Vibration':    W['vibration']* s['Vib'],
            'Machine Load': W['machine_load'] * s['ML'],
            'Noise':        W['noise']   * s['N'],
            'Pressure':     W['pressure']* s['P'],
            'Workers':      W['worker_density'] * s['WD'],
            'Fatigue':      W['fatigue'] * s['F'],
            'Forklift':     W['forklift']* s['FK'],
            'Door':         W['door_state'] * s['D'],
            'Ventilation':  -W['ventilation'] * (1 - s['Vent']),   # Reduces risk
        }

        R = sum(terms.values())
        R = max(0.0, min(1.0, R))   # Bounded [0,1]

        # Risk state classification (paper §III.E)
        if R < self.THETA_1:
            state = 'SAFE'
        elif R < self.THETA_2:
            state = 'WARNING'
        else:
            state = 'DANGER'

        # Ventilation logic (paper §III.F)
        vent_on = (s['G'] > 0.5 or R >= self.THETA_2)

        # Predictive alert: temp trend alone can trigger WARNING
        # even if absolute values are nominal (paper §III.F)
        is_predictive_warning = (T_prime > self.THETA_T) and (state == 'SAFE')

        # Sort contributions by absolute impact for explainability
        contributions = sorted(
            [{'name': k, 'value': v, 'abs': abs(v)} for k, v in terms.items()],
            key=lambda x: x['abs'], reverse=True
        )

        return {
            'R': R,
            'state': state,
            'vent_on': vent_on,
            'contributions': contributions,
            'normalized': s,
            'temp_trend': T_prime,
            'is_predictive_warning': is_predictive_warning,
        }

    def classify(self, R: float) -> str:
        """Classify a raw risk score."""
        if R < self.THETA_1:
            return 'SAFE'
        elif R < self.THETA_2:
            return 'WARNING'
        return 'DANGER'

    def explain(self, result: dict) -> str:
        """Generate a human-readable explanation of the risk score."""
        top3 = result['contributions'][:3]
        factors = [f"{c['name']} ({c['value']:+.3f})" for c in top3 if c['value'] > 0.01]
        return (
            f"R={result['R']:.3f} [{result['state']}] "
            f"driven by: {', '.join(factors) if factors else 'nominal conditions'}. "
            f"Vent: {'ON' if result['vent_on'] else 'OFF'}."
        )


# ─────────────────────────────────────────────────
# PREDICTION MODULE
# ─────────────────────────────────────────────────
class PredictionModule:
    """
    Predicts future risk score using linear regression over a rolling window.
    More sophisticated models (ARIMA, LSTM) can replace this for production.
    """

    def __init__(self, horizon: int = 30):
        self.horizon = horizon

    @staticmethod
    def linear_regression(data: list) -> tuple:
        """Ordinary Least Squares regression: returns (slope, intercept)."""
        n = len(data)
        if n < 2:
            return 0.0, data[-1] if data else 0.0
        x_mean = (n - 1) / 2.0
        y_mean = sum(data) / n
        num = sum((i - x_mean) * (y - y_mean) for i, y in enumerate(data))
        den = sum((i - x_mean) ** 2 for i in range(n))
        slope = num / den if den != 0 else 0.0
        intercept = y_mean - slope * x_mean
        return slope, intercept

    def predict(self, history: list) -> dict:
        """Predict R at t+horizon using linear extrapolation."""
        if len(history) < 3:
            current = history[-1] if history else 0.0
            return {
                'predicted': current, 'current': current,
                'spike_probability': 0.0, 'trend': 'insufficient_data',
                'slope': 0.0, 'horizon': self.horizon
            }

        window = history[-min(len(history), 30):]
        slope, intercept = self.linear_regression(window)
        x_pred = len(window) + self.horizon
        predicted = max(0.0, min(1.0, slope * x_pred + intercept))
        current = window[-1]

        # Spike probability: P(R_pred >= danger threshold)
        # Sigmoid function centered at theta_2=0.6
        danger_distance = predicted - 0.4
        spike_prob = max(0.0, min(1.0, danger_distance / 0.4)) if predicted > 0.4 else 0.0

        # Trend classification
        if slope > 0.003:
            trend = 'rising_fast'
        elif slope > 0.001:
            trend = 'rising'
        elif slope < -0.003:
            trend = 'falling_fast'
        elif slope < -0.001:
            trend = 'falling'
        else:
            trend = 'stable'

        return {
            'predicted': round(predicted, 4),
            'current': round(current, 4),
            'slope': round(slope, 6),
            'spike_probability': round(spike_prob, 4),
            'trend': trend,
            'horizon': self.horizon,
        }


# ─────────────────────────────────────────────────
# SYNTHETIC DATA GENERATOR
# ─────────────────────────────────────────────────
import random

class SyntheticGenerator:
    """
    Generates realistic synthetic sensor data with:
    - Gaussian noise on all channels
    - Correlated spike events (gas + motion, thermal)
    - Rare extreme events (~0.2% probability per tick)
    - Zone-specific baseline profiles
    - Auto-response ventilation
    """

    ZONE_BASELINES = {
        'A': {'temperature': 22, 'gas': 40,  'machine_load': 30, 'noise': 55, 'worker_density': 2},
        'B': {'temperature': 42, 'gas': 120, 'machine_load': 80, 'noise': 85, 'worker_density': 8},
        'C': {'temperature': 30, 'gas': 60,  'machine_load': 60, 'noise': 70, 'worker_density': 6},
        'D': {'temperature': 22, 'gas': 20,  'machine_load': 20, 'noise': 45, 'worker_density': 1},
    }

    def __init__(self, seed: int = None):
        if seed is not None:
            random.seed(seed)
        self.states = {z: self._init_state(z) for z in ['A', 'B', 'C', 'D']}
        self.spike: dict = None

    def _init_state(self, zone: str) -> dict:
        bl = self.ZONE_BASELINES[zone]
        return {
            'temperature':    bl.get('temperature', 25),
            'humidity':       50.0,
            'gas':            bl.get('gas', 50),
            'air_quality':    45.0,
            'radiation':      0.1,
            'vibration':      0.5,
            'machine_load':   bl.get('machine_load', 60),
            'noise':          bl.get('noise', 65),
            'pressure':       101.0,
            'motion':         0,
            'worker_density': bl.get('worker_density', 3),
            'fatigue':        3.0,
            'forklift':       2.0,
            'door_state':     0,
            'ventilation':    80.0,
        }

    @staticmethod
    def _noisy(val, std, lo=0.0, hi=100.0, drift=0.0) -> float:
        return max(lo, min(hi, val + random.gauss(0, std) + drift))

    def _trigger_spike(self):
        if self.spike is None and random.random() < 0.002:
            self.spike = {
                'zone':     random.choice(['A', 'B', 'C', 'D']),
                'type':     random.choice(['gas_motion', 'thermal']),
                'duration': random.randint(15, 45),
                'tick':     0,
            }

    def tick(self) -> dict:
        """Advance simulation by 1 second. Returns dict of zone → sensor readings."""
        self._trigger_spike()
        if self.spike:
            self.spike['tick'] += 1
            if self.spike['tick'] >= self.spike['duration']:
                self.spike = None

        results = {}
        for zone, s in self.states.items():
            is_spike    = self.spike and self.spike['zone'] == zone
            gas_spike   = is_spike and self.spike['type'] == 'gas_motion'
            heat_spike  = is_spike and self.spike['type'] == 'thermal'
            sf = (math.sin(math.pi * self.spike['tick'] / self.spike['duration'])
                  if is_spike else 0.0)

            s['temperature']    = self._noisy(s['temperature'],    0.6, 10, 90, sf*3 if heat_spike else 0)
            s['humidity']       = self._noisy(s['humidity'],       1.0, 20, 95)
            s['gas']            = self._noisy(s['gas'],            12,  0,  900, sf*200 if gas_spike else 0)
            s['air_quality']    = self._noisy(s['air_quality'],    6,   10, 450, sf*80  if gas_spike else 0)
            s['radiation']      = self._noisy(s['radiation'],      0.03, 0, 8)
            s['vibration']      = self._noisy(s['vibration'],      0.15, 0, 8)
            s['machine_load']   = self._noisy(s['machine_load'],   2.5, 0,  100)
            s['noise']          = self._noisy(s['noise'],          1.5, 30, 115)
            s['pressure']       = self._noisy(s['pressure'],       0.8, 90, 115)
            s['worker_density'] = self._noisy(s['worker_density'], 0.2, 0,  18)
            s['fatigue']        = self._noisy(s['fatigue'],        0.15, 0, 9.5)
            s['forklift']       = self._noisy(s['forklift'],       0.2, 0,  9)

            if gas_spike and sf > 0.5:
                s['motion'] = 1
            elif random.random() < 0.02:
                s['motion'] = 1 - s['motion']

            if random.random() < 0.008:
                s['door_state'] = 1 - s['door_state']

            if s['gas'] / 1000 > 0.5:
                s['ventilation'] = min(s['ventilation'] + 2, 100)
            else:
                s['ventilation'] = self._noisy(s['ventilation'], 0.5, 40, 100)

            results[zone] = {k: round(v, 3) if isinstance(v, float) else v
                             for k, v in s.items()}
        return results

    def generate_dataset(self, n_samples: int, zone: str = 'B',
                          engine: 'RiskEngine' = None) -> list:
        """Generate labeled dataset for a given zone."""
        if engine is None:
            engine = RiskEngine()
        temp_hist = deque(maxlen=10)
        records = []
        for _ in range(n_samples):
            data = self.tick()
            sensors = data[zone]
            temp_hist.append(sensors['temperature'])
            result = engine.compute(sensors, temp_hist)
            records.append({
                **sensors,
                'R':          result['R'],
                'state':      result['state'],
                'vent_on':    result['vent_on'],
                'temp_trend': result['temp_trend'],
            })
        return records


# ─────────────────────────────────────────────────
# DEMO / MAIN
# ─────────────────────────────────────────────────
if __name__ == '__main__':
    import json

    engine = RiskEngine()
    predictor = PredictionModule(horizon=30)
    generator = SyntheticGenerator(seed=42)

    print("=" * 60)
    print("Adaptive Safety Digital Twin — Risk Engine Demo")
    print("=" * 60)

    risk_history = deque(maxlen=100)
    temp_history = deque(maxlen=10)

    print("\nRunning 10-second simulation for Zone B:\n")
    for t in range(10):
        data = generator.tick()
        sensors = data['B']
        temp_history.append(sensors['temperature'])
        result = engine.compute(sensors, temp_history)
        risk_history.append(result['R'])
        prediction = predictor.predict(list(risk_history))

        print(f"t={t+1:2d}s | T={sensors['temperature']:.1f}°C "
              f"Gas={sensors['gas']:.0f}ppm M={sensors['motion']} "
              f"| R={result['R']:.3f} [{result['state']:<7}] "
              f"Pred+30s={prediction['predicted']:.3f} "
              f"({prediction['trend']})")
        print(f"      Explanation: {engine.explain(result)}")

    print("\n\nDataset sample (5 records, Zone B):")
    dataset = generator.generate_dataset(5, 'B', engine)
    for rec in dataset:
        print(f"  gas={rec['gas']:.0f}ppm T={rec['temperature']:.1f}°C "
              f"motion={rec['motion']} → R={rec['R']:.3f} [{rec['state']}]")
